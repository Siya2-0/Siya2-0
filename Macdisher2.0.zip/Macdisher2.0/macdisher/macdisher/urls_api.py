from django.urls import path,include
from .api import DeviceApiView

urlpatterns = [
    # path('device/', DeviceApiView.as_view()),
    # API view urls

]
