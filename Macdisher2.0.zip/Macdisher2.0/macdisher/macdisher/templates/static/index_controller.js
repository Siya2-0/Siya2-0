// (() => {

//   class IndexController {
//     check() {
//       console.log('Check IndexController')
//     }
//   }
//   window.IndexController = IndexController
// })()

class IndexController {
  check() {
    console.log('Check IndexController')
  }
}

export { IndexController }
