from django import forms
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
from django.forms import CharField
from django.db import models

class LoginForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('username', 'password',)

class PaginationForm(forms.ModelForm):
    class Meta:
        fields = ('offset', 'limit', )

