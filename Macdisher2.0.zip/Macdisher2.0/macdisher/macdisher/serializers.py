from abc import ABC
from django.contrib.auth import get_user_model
from rest_framework import serializers

from django.utils.dateparse import parse_datetime

# Django Rest Framework serializers go here
