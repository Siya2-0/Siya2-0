from django.urls import path, include
from . import views

urlpatterns = [
    # Base production URLs
    path('', views.macdisher_index, name='macdisher_index'),

    path("filter/", views.macdisher_search, name='fitler'),

]
