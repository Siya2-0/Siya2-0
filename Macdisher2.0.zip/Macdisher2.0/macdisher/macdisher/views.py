from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpRequest, HttpResponseNotFound
from .models import Mac
from django import forms

@login_required
def macdisher_index(request):
    return render(request, 'macdisher/index.html')


def macdisher_search(request):
    if(request.method=="POST"):

    #   //  form =MyForm(request.POST)
        db=Mac.objects.all()
       
        result=0
        # if form.is_valid():
        #     result=0

        if "FilterOnMac"  in request.POST:
            macInput=request.POST.get("TextInput")
            result=db.filter(mac==macInput)


        elif "FilterOnDevice"  in   request.POST:
            DeviceInput=request.POST.get("TextInput")
            #DeviceInput=form.cleaned_data["TextInput"]
            result=db.filter(device==DeviceInput)
        
        elif "FilterOnAllocation"  in   request.POST:
            AllocationInput=request.POST.get("TextInput")
           # AllocationInput=form.cleaned_data["TextInput"]
            result=db.filter(device==AllocationInput)
                 
        else:
            result= "error"


        context ={"Mac_Adress": result}
    
        return render (request ,'macdisher/index.html', context)
    

    return render (request ,'macdisher/index.html')


