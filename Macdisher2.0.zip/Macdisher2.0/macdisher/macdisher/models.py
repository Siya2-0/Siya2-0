from django.conf import settings
from django.db import models

# Create your models here.
class DockMac(models.Model):
    id=models.AutoField(max_length=11, null=False, primary_key=True)
    allocation=models.CharField(max_length=255, null=True)
    device=models.CharField(max_length=255, null=True)
    mac=models.CharField(max_length=255, null=True)
    metastring=models.CharField(max_length=255, null=True)
    time=models.TimeField(null=True)
    user=models.CharField(max_length=255, null=True)


class Mac(models.Model):
    id=models.IntegerField(max_length=11, null=False, primary_key=True)
    allocation=models.CharField(max_length=255, null=True)
    device=models.CharField(max_length=255, null=True)
    mac=models.CharField(max_length=255, null=True)
    metastring=models.CharField(max_length=255, null=True)
    time=models.TimeField(null=True)
    user=models.CharField(max_length=255, null=True)
    class Meta:
       constraints= [
           models.UniqueConstraint(name="UK_g57pk2rb6rurwecw1k6yc93e", fields=['mac'] )
       ]